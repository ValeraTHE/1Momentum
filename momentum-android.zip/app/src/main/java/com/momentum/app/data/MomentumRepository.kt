package com.momentum.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class MomentumRepository(context: Context) {
    private val appContext = context.applicationContext
    private val stateFile = File(appContext.filesDir, "momentum_state_v1.json")
    private val tempFile = File(appContext.filesDir, "momentum_state_v1.tmp")
    private val mutex = Mutex()

    val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    suspend fun loadState(): MomentumState = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!stateFile.exists()) {
                val initial = SpherePalette.defaultState()
                saveInternal(initial)
                return@withLock initial
            }
            return@withLock try {
                val raw = stateFile.readText(Charsets.UTF_8)
                val parsed = json.decodeFromString<MomentumState>(raw)
                if (parsed.spheres.isEmpty()) {
                    parsed.copy(spheres = SpherePalette.defaultState().spheres)
                } else {
                    parsed
                }
            } catch (_: Exception) {
                val fallback = SpherePalette.defaultState()
                saveInternal(fallback)
                fallback
            }
        }
    }

    suspend fun saveState(state: MomentumState) = withContext(Dispatchers.IO) {
        mutex.withLock {
            saveInternal(state)
        }
    }

    private fun saveInternal(state: MomentumState) {
        val serialized = json.encodeToString(state)
        tempFile.writeText(serialized, Charsets.UTF_8)
        if (!tempFile.renameTo(stateFile)) {
            stateFile.writeText(serialized, Charsets.UTF_8)
            tempFile.delete()
        }
    }

    fun exportToJson(state: MomentumState): String = json.encodeToString(state)

    fun importFromJson(rawJson: String): Result<MomentumState> = runCatching {
        val parsed = json.decodeFromString<MomentumState>(rawJson.trim())
        if (parsed.spheres.isEmpty()) {
            parsed.copy(spheres = SpherePalette.defaultState().spheres)
        } else {
            parsed
        }
    }
}
