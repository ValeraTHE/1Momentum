package com.momentum.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.momentum.app.ui.MainTab
import com.momentum.app.ui.MomentumViewModel
import com.momentum.app.ui.components.CreateType
import com.momentum.app.ui.components.EditorTarget
import com.momentum.app.ui.components.ItemEditorSheet
import com.momentum.app.ui.screens.FocusScreen
import com.momentum.app.ui.screens.SettingsScreen
import com.momentum.app.ui.screens.StatsScreen
import com.momentum.app.ui.theme.LocalMomentumColors
import com.momentum.app.ui.theme.MomentumTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MomentumApp()
        }
    }
}

@Composable
private fun MomentumApp(vm: MomentumViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val selectedDate by vm.selectedDate.collectAsState()
    val visibleMonth by vm.visibleMonth.collectAsState()
    val statusBanner by vm.statusBanner.collectAsState()

    var currentTab by rememberSaveable { mutableStateOf(MainTab.FOCUS) }
    var editorTarget by remember { mutableStateOf<EditorTarget?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusBanner) {
        val message = statusBanner
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            vm.clearBanner()
        }
    }

    MomentumTheme(
        darkTheme = state.settings.darkTheme,
        accentPreset = state.settings.accentPreset
    ) {
        val colors = LocalMomentumColors.current

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.background),
            containerColor = colors.background,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            floatingActionButton = {
                if (currentTab == MainTab.FOCUS) {
                    FloatingActionButton(
                        onClick = { editorTarget = EditorTarget.CreateNew(CreateType.TASK) },
                        containerColor = colors.accent,
                        contentColor = colors.onAccent,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Добавить запись"
                        )
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = colors.surface,
                    tonalElevation = 0.dp,
                    modifier = Modifier.border(width = 0.5.dp, color = colors.border)
                ) {
                    MainTab.entries.forEach { tab ->
                        val selected = currentTab == tab
                        val icon = when (tab) {
                            MainTab.FOCUS -> Icons.Rounded.CalendarMonth
                            MainTab.STATS -> Icons.Rounded.BarChart
                            MainTab.SETTINGS -> Icons.Rounded.Tune
                        }
                        NavigationBarItem(
                            selected = selected,
                            onClick = { currentTab = tab },
                            icon = { Icon(imageVector = icon, contentDescription = tab.title) },
                            label = { Text(tab.title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = colors.accent,
                                selectedTextColor = colors.accent,
                                indicatorColor = colors.accent.copy(alpha = 0.14f),
                                unselectedIconColor = colors.textSecondary,
                                unselectedTextColor = colors.textSecondary
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentTab, label = "main_tabs") { tab ->
                    when (tab) {
                        MainTab.FOCUS -> FocusScreen(
                            state = state,
                            selectedDate = selectedDate,
                            visibleMonth = visibleMonth,
                            onSelectDate = vm::selectDate,
                            onShiftMonth = vm::shiftMonth,
                            onJumpToday = vm::jumpToToday,
                            onSetHabitTier = vm::setHabitTier,
                            onToggleBinaryHabit = vm::toggleBinaryHabit,
                            onToggleTask = vm::toggleTaskCompleted,
                            onToggleEvent = vm::toggleEventCompleted,
                            onSaveDayNote = vm::saveDayNote,
                            onOpenEditor = { editorTarget = it }
                        )

                        MainTab.STATS -> StatsScreen(
                            state = state,
                            onBuyFreezeToken = vm::buyFreezeToken,
                            onFreezeDate = vm::freezeDate,
                            onOpenDay = { date ->
                                vm.selectDate(date)
                                currentTab = MainTab.FOCUS
                            }
                        )

                        MainTab.SETTINGS -> SettingsScreen(
                            state = state,
                            onUpdateSettings = vm::updateSettings,
                            onUpsertSphere = vm::upsertSphere,
                            onDeleteSphere = vm::deleteSphere,
                            onRestartSprint = vm::restartSprintToday,
                            onExportJson = vm::exportJson,
                            onImportJson = vm::importJson,
                            onResetAll = vm::resetAllData
                        )
                    }
                }
            }

            val activeEditor = editorTarget
            if (activeEditor != null) {
                ItemEditorSheet(
                    target = activeEditor,
                    selectedDate = selectedDate,
                    spheres = state.spheres,
                    onDismiss = { editorTarget = null },
                    onSaveTask = vm::upsertTask,
                    onDeleteTask = vm::deleteTask,
                    onSaveHabit = vm::upsertHabit,
                    onDeleteHabit = vm::deleteHabit,
                    onSaveEvent = vm::upsertEvent,
                    onDeleteEvent = vm::deleteEvent
                )
            }
        }
    }
}
