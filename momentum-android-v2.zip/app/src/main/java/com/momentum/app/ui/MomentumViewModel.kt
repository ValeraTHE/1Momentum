package com.momentum.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.momentum.app.data.AppSettings
import com.momentum.app.data.DayRecord
import com.momentum.app.data.EventItem
import com.momentum.app.data.Habit
import com.momentum.app.data.HabitTier
import com.momentum.app.data.MomentumRepository
import com.momentum.app.data.MomentumState
import com.momentum.app.data.ProgressEngine
import com.momentum.app.data.Sphere
import com.momentum.app.data.SpherePalette
import com.momentum.app.data.TaskItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters
import java.util.UUID

enum class MainTab(val title: String) {
    FOCUS("Фокус"),
    STATS("Прогресс"),
    SETTINGS("Настройки")
}

class MomentumViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MomentumRepository(application)

    private val _state = MutableStateFlow(SpherePalette.defaultState())
    val state: StateFlow<MomentumState> = _state.asStateFlow()

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    private val _visibleMonth = MutableStateFlow(YearMonth.now())
    val visibleMonth: StateFlow<YearMonth> = _visibleMonth.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    init {
        viewModelScope.launch {
            _state.value = repository.loadState()
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    private fun updateState(transform: (MomentumState) -> MomentumState) {
        val next = transform(_state.value)
        _state.value = next
        viewModelScope.launch {
            repository.saveState(next)
        }
    }

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
        _visibleMonth.value = YearMonth.from(date)
    }

    fun jumpToToday() {
        val today = LocalDate.now()
        _selectedDate.value = today
        _visibleMonth.value = YearMonth.from(today)
    }

    fun shiftMonth(delta: Long) {
        _visibleMonth.value = _visibleMonth.value.plusMonths(delta)
    }

    fun setHabitTier(habitId: String, date: LocalDate, tier: HabitTier) {
        val key = date.toString()
        updateState { current ->
            val oldRecord = current.dayRecords[key] ?: DayRecord()
            val updatedMap = oldRecord.habitCompletions.toMutableMap()
            if (tier == HabitTier.NONE) {
                updatedMap.remove(habitId)
            } else {
                updatedMap[habitId] = tier
            }
            val newRecord = oldRecord.copy(habitCompletions = updatedMap)
            val newRecords = current.dayRecords.toMutableMap()
            if (newRecord.habitCompletions.isEmpty() && newRecord.note.isBlank()) {
                newRecords.remove(key)
            } else {
                newRecords[key] = newRecord
            }
            current.copy(dayRecords = newRecords)
        }
    }

    fun toggleBinaryHabit(habitId: String, date: LocalDate) {
        val key = date.toString()
        val existing = _state.value.dayRecords[key]?.habitCompletions?.get(habitId) ?: HabitTier.NONE
        val next = if (existing == HabitTier.NONE) HabitTier.BASE else HabitTier.NONE
        setHabitTier(habitId, date, next)
    }

    fun saveDayNote(date: LocalDate, note: String) {
        val key = date.toString()
        updateState { current ->
            val oldRecord = current.dayRecords[key] ?: DayRecord()
            val newRecord = oldRecord.copy(note = note.trim())
            val newRecords = current.dayRecords.toMutableMap()
            if (newRecord.habitCompletions.isEmpty() && newRecord.note.isBlank()) {
                newRecords.remove(key)
            } else {
                newRecords[key] = newRecord
            }
            current.copy(dayRecords = newRecords)
        }
    }

    fun upsertHabit(habit: Habit) {
        updateState { current ->
            val exists = current.habits.any { it.id == habit.id }
            val updated = if (exists) {
                current.habits.map { if (it.id == habit.id) habit else it }
            } else {
                current.habits + habit
            }
            current.copy(habits = updated)
        }
    }

    fun deleteHabit(habitId: String) {
        updateState { current ->
            current.copy(habits = current.habits.filterNot { it.id == habitId })
        }
    }

    fun upsertTask(task: TaskItem) {
        updateState { current ->
            val exists = current.tasks.any { it.id == task.id }
            val updated = if (exists) {
                current.tasks.map { if (it.id == task.id) task else it }
            } else {
                current.tasks + task
            }
            current.copy(tasks = updated)
        }
    }

    fun toggleTaskCompleted(taskId: String, dateContext: LocalDate) {
        updateState { current ->
            val updated = current.tasks.map { task ->
                if (task.id == taskId) {
                    val nowCompleted = !task.isCompleted
                    task.copy(
                        isCompleted = nowCompleted,
                        completedDate = if (nowCompleted) (task.date ?: dateContext.toString()) else null
                    )
                } else {
                    task
                }
            }
            current.copy(tasks = updated)
        }
    }

    fun deleteTask(taskId: String) {
        updateState { current ->
            current.copy(tasks = current.tasks.filterNot { it.id == taskId })
        }
    }

    fun upsertEvent(event: EventItem) {
        updateState { current ->
            val exists = current.events.any { it.id == event.id }
            val updated = if (exists) {
                current.events.map { if (it.id == event.id) event else it }
            } else {
                current.events + event
            }
            current.copy(events = updated)
        }
    }

    fun toggleEventCompleted(eventId: String) {
        updateState { current ->
            val updated = current.events.map { event ->
                if (event.id == eventId) event.copy(isCompleted = !event.isCompleted) else event
            }
            current.copy(events = updated)
        }
    }

    fun deleteEvent(eventId: String) {
        updateState { current ->
            current.copy(events = current.events.filterNot { it.id == eventId })
        }
    }

    fun buyFreezeToken() {
        val current = _state.value
        val levelInfo = ProgressEngine.calculateLevelInfo(current)
        val cost = current.settings.freezeCostXp
        if (levelInfo.availableXp < cost) {
            _statusBanner.value = "Недостаточно XP: нужно $cost XP (доступно ${levelInfo.availableXp} XP)"
            return
        }
        updateState {
            it.copy(
                spentXp = it.spentXp + cost,
                freezeTokens = it.freezeTokens + 1
            )
        }
        _statusBanner.value = "Жетон заморозки куплен"
    }

    fun freezeDate(date: LocalDate) {
        val current = _state.value
        val key = date.toString()
        if (key in current.frozenDates) return
        if (current.freezeTokens <= 0) {
            _statusBanner.value = "Нет доступных жетонов заморозки"
            return
        }
        updateState {
            it.copy(
                freezeTokens = (it.freezeTokens - 1).coerceAtLeast(0),
                frozenDates = it.frozenDates + key
            )
        }
        _statusBanner.value = "Серия защищена заморозкой за $key"
    }

    fun upsertSphere(id: String?, name: String, colorHex: Long) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        updateState { current ->
            if (id != null && current.spheres.any { it.id == id }) {
                current.copy(
                    spheres = current.spheres.map {
                        if (it.id == id) it.copy(name = trimmed, colorHex = colorHex) else it
                    }
                )
            } else {
                current.copy(
                    spheres = current.spheres + Sphere(
                        id = UUID.randomUUID().toString(),
                        name = trimmed,
                        colorHex = colorHex
                    )
                )
            }
        }
    }

    fun deleteSphere(sphereId: String) {
        val current = _state.value
        if (current.spheres.size <= 1) {
            _statusBanner.value = "Должна остаться хотя бы одна сфера"
            return
        }
        val fallbackId = current.spheres.first { it.id != sphereId }.id
        updateState { state ->
            state.copy(
                spheres = state.spheres.filterNot { it.id == sphereId },
                habits = state.habits.map { if (it.sphereId == sphereId) it.copy(sphereId = fallbackId) else it },
                tasks = state.tasks.map { if (it.sphereId == sphereId) it.copy(sphereId = fallbackId) else it },
                events = state.events.map { if (it.sphereId == sphereId) it.copy(sphereId = fallbackId) else it }
            )
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        updateState { current ->
            current.copy(settings = transform(current.settings))
        }
    }

    fun restartSprintToday() {
        val monday = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()
        updateSettings { it.copy(sprintStartDate = monday) }
        _statusBanner.value = "Новый спринт запущен с этой недели"
    }

    fun exportJson(): String = repository.exportToJson(_state.value)

    fun importJson(raw: String): Boolean {
        val result = repository.importFromJson(raw)
        return result.fold(
            onSuccess = { imported ->
                _state.value = imported
                viewModelScope.launch { repository.saveState(imported) }
                _statusBanner.value = "Данные успешно восстановлены"
                true
            },
            onFailure = {
                _statusBanner.value = "Ошибка формата JSON — проверьте текст"
                false
            }
        )
    }

    fun resetAllData() {
        val fresh = SpherePalette.defaultState()
        _state.value = fresh
        viewModelScope.launch { repository.saveState(fresh) }
        _statusBanner.value = "Данные сброшены к начальным"
    }
}
