package com.momentum.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.momentum.app.data.EventItem
import com.momentum.app.data.Habit
import com.momentum.app.data.Sphere
import com.momentum.app.data.TaskItem
import com.momentum.app.ui.theme.LocalMomentumColors
import java.time.LocalDate
import java.util.UUID

sealed class EditorTarget {
    data class CreateNew(val initialType: CreateType = CreateType.TASK) : EditorTarget()
    data class EditTask(val task: TaskItem) : EditorTarget()
    data class EditHabit(val habit: Habit) : EditorTarget()
    data class EditEvent(val event: EventItem) : EditorTarget()
}

enum class CreateType(val title: String) {
    TASK("Задача"),
    HABIT("Привычка"),
    EVENT("Событие")
}

private val weekDayChips = listOf(
    1 to "Пн",
    2 to "Вт",
    3 to "Ср",
    4 to "Чт",
    5 to "Пт",
    6 to "Сб",
    7 to "Вс"
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ItemEditorSheet(
    target: EditorTarget,
    selectedDate: LocalDate,
    spheres: List<Sphere>,
    onDismiss: () -> Unit,
    onSaveTask: (TaskItem) -> Unit,
    onDeleteTask: (String) -> Unit,
    onSaveHabit: (Habit) -> Unit,
    onDeleteHabit: (String) -> Unit,
    onSaveEvent: (EventItem) -> Unit,
    onDeleteEvent: (String) -> Unit
) {
    val colors = LocalMomentumColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val defaultSphereId = spheres.firstOrNull()?.id ?: "sphere_focus"

    var activeType by remember(target) {
        mutableStateOf(
            when (target) {
                is EditorTarget.CreateNew -> target.initialType
                is EditorTarget.EditTask -> CreateType.TASK
                is EditorTarget.EditHabit -> CreateType.HABIT
                is EditorTarget.EditEvent -> CreateType.EVENT
            }
        )
    }

    val isEditing = target !is EditorTarget.CreateNew

    var title by remember(target) {
        mutableStateOf(
            when (target) {
                is EditorTarget.EditTask -> target.task.title
                is EditorTarget.EditHabit -> target.habit.title
                is EditorTarget.EditEvent -> target.event.title
                is EditorTarget.CreateNew -> ""
            }
        )
    }

    var note by remember(target) {
        mutableStateOf(
            when (target) {
                is EditorTarget.EditTask -> target.task.note
                is EditorTarget.EditEvent -> target.event.note
                else -> ""
            }
        )
    }

    var selectedSphereId by remember(target) {
        mutableStateOf(
            when (target) {
                is EditorTarget.EditTask -> target.task.sphereId
                is EditorTarget.EditHabit -> target.habit.sphereId
                is EditorTarget.EditEvent -> target.event.sphereId
                is EditorTarget.CreateNew -> defaultSphereId
            }
        )
    }

    var assignToSelectedDate by remember(target) {
        mutableStateOf(
            when (target) {
                is EditorTarget.EditTask -> target.task.date != null
                else -> true
            }
        )
    }
    var priority by remember(target) {
        mutableIntStateOf(
            when (target) {
                is EditorTarget.EditTask -> target.task.priority
                else -> 1
            }
        )
    }

    var isElastic by remember(target) {
        mutableStateOf(
            when (target) {
                is EditorTarget.EditHabit -> target.habit.isElastic
                else -> true
            }
        )
    }
    var daysOfWeek by remember(target) {
        mutableStateOf(
            when (target) {
                is EditorTarget.EditHabit -> target.habit.daysOfWeek
                else -> setOf(1, 2, 3, 4, 5, 6, 7)
            }
        )
    }
    var minLabel by remember(target) {
        mutableStateOf(if (target is EditorTarget.EditHabit) target.habit.minLabel else "5 мин")
    }
    var baseLabel by remember(target) {
        mutableStateOf(if (target is EditorTarget.EditHabit) target.habit.baseLabel else "20 мин")
    }
    var maxLabel by remember(target) {
        mutableStateOf(if (target is EditorTarget.EditHabit) target.habit.maxLabel else "45 мин")
    }

    var eventTime by remember(target) {
        mutableStateOf(if (target is EditorTarget.EditEvent) target.event.time else "14:00")
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.surface,
        contentColor = colors.textPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isEditing) "Редактирование" else "Новая запись",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.textPrimary
                )
                if (isEditing) {
                    IconButton(onClick = {
                        when (target) {
                            is EditorTarget.EditTask -> onDeleteTask(target.task.id)
                            is EditorTarget.EditHabit -> onDeleteHabit(target.habit.id)
                            is EditorTarget.EditEvent -> onDeleteEvent(target.event.id)
                            else -> Unit
                        }
                        onDismiss()
                    }) {
                        Icon(
                            imageVector = Icons.Rounded.Delete,
                            contentDescription = "Удалить",
                            tint = colors.danger
                        )
                    }
                }
            }

            if (!isEditing) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(colors.surfaceElevated)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    CreateType.entries.forEach { type ->
                        val selected = activeType == type
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(9.dp))
                                .background(if (selected) colors.accent else Color.Transparent)
                                .clickable { activeType = type }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = type.title,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) colors.onAccent else colors.textSecondary
                            )
                        }
                    }
                }
            }

            val fieldColors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.border,
                focusedTextColor = colors.textPrimary,
                unfocusedTextColor = colors.textPrimary,
                focusedLabelColor = colors.accent,
                unfocusedLabelColor = colors.textSecondary,
                cursorColor = colors.accent
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = fieldColors
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Сфера (цветовая метка)",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    spheres.forEach { sphere ->
                        val isSelected = sphere.id == selectedSphereId
                        val sColor = Color(sphere.colorHex)
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) sColor.copy(alpha = 0.2f) else colors.surfaceElevated)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) sColor else colors.border,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedSphereId = sphere.id }
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(sColor)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = sphere.name,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isSelected) colors.textPrimary else colors.textSecondary
                            )
                        }
                    }
                }
            }

            when (activeType) {
                CreateType.TASK -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Привязать к дате ($selectedDate)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Если выключить — попадёт в общий бэклог",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = assignToSelectedDate,
                            onCheckedChange = { assignToSelectedDate = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = colors.onAccent,
                                checkedTrackColor = colors.accent
                            )
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Сложность и награда",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.textSecondary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                1 to "Обычная\n15 XP",
                                2 to "Важная\n30 XP",
                                3 to "Ключевая\n50 XP"
                            ).forEach { (level, label) ->
                                val selected = priority == level
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (selected) colors.accent.copy(alpha = 0.18f) else colors.surfaceElevated)
                                        .border(
                                            1.dp,
                                            if (selected) colors.accent else colors.border,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable { priority = level }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        textAlign = TextAlign.Center,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (selected) colors.accent else colors.textSecondary
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Заметка (необязательно)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = fieldColors
                    )
                }

                CreateType.HABIT -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Эластичная (3 уровня)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Мин (10 XP) / База (25 XP) / Макс (50 XP)",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = isElastic,
                            onCheckedChange = { isElastic = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = colors.onAccent,
                                checkedTrackColor = colors.accent
                            )
                        )
                    }

                    if (isElastic) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = minLabel,
                                onValueChange = { minLabel = it },
                                label = { Text("Мин") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = fieldColors
                            )
                            OutlinedTextField(
                                value = baseLabel,
                                onValueChange = { baseLabel = it },
                                label = { Text("База") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = fieldColors
                            )
                            OutlinedTextField(
                                value = maxLabel,
                                onValueChange = { maxLabel = it },
                                label = { Text("Макс") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = fieldColors
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Дни повторения",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.textSecondary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            weekDayChips.forEach { (dow, label) ->
                                val active = dow in daysOfWeek
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (active) colors.accent else colors.surfaceElevated)
                                        .clickable {
                                            val updated = if (active && daysOfWeek.size > 1) {
                                                daysOfWeek - dow
                                            } else {
                                                daysOfWeek + dow
                                            }
                                            daysOfWeek = updated
                                        }
                                        .padding(vertical = 9.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                        color = if (active) colors.onAccent else colors.textSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                CreateType.EVENT -> {
                    OutlinedTextField(
                        value = eventTime,
                        onValueChange = { eventTime = it },
                        label = { Text("Время (например, 14:00)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = fieldColors
                    )

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Детали события (необязательно)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = fieldColors
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            Button(
                onClick = {
                    val cleanTitle = title.trim()
                    if (cleanTitle.isEmpty()) return@Button
                    when (activeType) {
                        CreateType.TASK -> {
                            val existing = (target as? EditorTarget.EditTask)?.task
                            val dateValue = if (assignToSelectedDate) {
                                existing?.date ?: selectedDate.toString()
                            } else {
                                null
                            }
                            onSaveTask(
                                TaskItem(
                                    id = existing?.id ?: UUID.randomUUID().toString(),
                                    title = cleanTitle,
                                    note = note.trim(),
                                    sphereId = selectedSphereId,
                                    date = dateValue,
                                    priority = priority,
                                    isCompleted = existing?.isCompleted ?: false,
                                    completedDate = existing?.completedDate
                                )
                            )
                        }

                        CreateType.HABIT -> {
                            val existing = (target as? EditorTarget.EditHabit)?.habit
                            onSaveHabit(
                                Habit(
                                    id = existing?.id ?: UUID.randomUUID().toString(),
                                    title = cleanTitle,
                                    sphereId = selectedSphereId,
                                    isElastic = isElastic,
                                    daysOfWeek = daysOfWeek,
                                    minLabel = minLabel.trim().ifEmpty { "Мин" },
                                    baseLabel = baseLabel.trim().ifEmpty { "База" },
                                    maxLabel = maxLabel.trim().ifEmpty { "Макс" },
                                    createdDate = existing?.createdDate ?: selectedDate.toString()
                                )
                            )
                        }

                        CreateType.EVENT -> {
                            val existing = (target as? EditorTarget.EditEvent)?.event
                            onSaveEvent(
                                EventItem(
                                    id = existing?.id ?: UUID.randomUUID().toString(),
                                    title = cleanTitle,
                                    note = note.trim(),
                                    sphereId = selectedSphereId,
                                    date = existing?.date ?: selectedDate.toString(),
                                    time = eventTime.trim(),
                                    isCompleted = existing?.isCompleted ?: false
                                )
                            )
                        }
                    }
                    onDismiss()
                },
                enabled = title.trim().isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = colors.accent,
                    contentColor = colors.onAccent
                )
            ) {
                Text(
                    text = if (isEditing) "Сохранить изменения" else "Добавить",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}
