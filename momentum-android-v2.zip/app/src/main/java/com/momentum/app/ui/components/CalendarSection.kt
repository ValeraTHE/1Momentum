package com.momentum.app.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.app.data.MomentumState
import com.momentum.app.data.ProgressEngine
import com.momentum.app.ui.theme.LocalMomentumColors
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

private val russianMonths = listOf(
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
)

private val russianWeekDays = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

@Composable
fun CalendarSection(
    state: MomentumState,
    selectedDate: LocalDate,
    visibleMonth: YearMonth,
    isMonthExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onSelectDate: (LocalDate) -> Unit,
    onShiftMonth: (Long) -> Unit,
    onJumpToday: () -> Unit
) {
    val colors = LocalMomentumColors.current
    val today = LocalDate.now()
    val sphereColorMap = state.spheres.associate { it.id to Color(it.colorHex) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(18.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val displayMonth = if (isMonthExpanded) visibleMonth else YearMonth.from(selectedDate)
                Text(
                    text = "${russianMonths[displayMonth.monthValue - 1]} ${displayMonth.year}",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                if (selectedDate != today) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.accent.copy(alpha = 0.16f))
                            .clickable { onJumpToday() }
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "Сегодня",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.accent
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isMonthExpanded) {
                    IconButton(
                        onClick = { onShiftMonth(-1) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ChevronLeft,
                            contentDescription = "Предыдущий месяц",
                            tint = colors.textSecondary
                        )
                    }
                    IconButton(
                        onClick = { onShiftMonth(1) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = "Следующий месяц",
                            tint = colors.textSecondary
                        )
                    }
                } else {
                    IconButton(
                        onClick = { onSelectDate(selectedDate.minusWeeks(1)) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ChevronLeft,
                            contentDescription = "Предыдущая неделя",
                            tint = colors.textSecondary
                        )
                    }
                    IconButton(
                        onClick = { onSelectDate(selectedDate.plusWeeks(1)) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = "Следующая неделя",
                            tint = colors.textSecondary
                        )
                    }
                }

                Spacer(Modifier.width(2.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.surfaceElevated)
                        .clickable { onToggleExpand() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isMonthExpanded) "Неделя" else "Месяц",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary
                        )
                        Icon(
                            imageVector = if (isMonthExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                            contentDescription = null,
                            tint = colors.textSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            russianWeekDays.forEach { dayName ->
                Text(
                    text = dayName,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textSecondary
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        AnimatedContent(targetState = isMonthExpanded, label = "calendar_mode") { expanded ->
            if (!expanded) {
                val weekStart = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (i in 0..6) {
                        val date = weekStart.plusDays(i.toLong())
                        CalendarDayCell(
                            modifier = Modifier.weight(1f),
                            date = date,
                            isSelected = date == selectedDate,
                            isToday = date == today,
                            state = state,
                            sphereColorMap = sphereColorMap,
                            onClick = { onSelectDate(date) }
                        )
                    }
                }
            } else {
                val firstDayOfMonth = visibleMonth.atDay(1)
                val leadingEmpty = firstDayOfMonth.dayOfWeek.value - 1
                val daysInMonth = visibleMonth.lengthOfMonth()
                val totalCells = ((leadingEmpty + daysInMonth + 6) / 7) * 7
                val weeks = totalCells / 7

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (week in 0 until weeks) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            for (dayCol in 0..6) {
                                val cellIndex = week * 7 + dayCol
                                val dayOffset = cellIndex - leadingEmpty
                                if (dayOffset in 0 until daysInMonth) {
                                    val date = visibleMonth.atDay(dayOffset + 1)
                                    CalendarDayCell(
                                        modifier = Modifier.weight(1f),
                                        date = date,
                                        isSelected = date == selectedDate,
                                        isToday = date == today,
                                        state = state,
                                        sphereColorMap = sphereColorMap,
                                        onClick = { onSelectDate(date) }
                                    )
                                } else {
                                    Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    modifier: Modifier,
    date: LocalDate,
    isSelected: Boolean,
    isToday: Boolean,
    state: MomentumState,
    sphereColorMap: Map<String, Color>,
    onClick: () -> Unit
) {
    val colors = LocalMomentumColors.current
    val summary = ProgressEngine.calculateDaySummary(state, date)

    val fillIntensity = when {
        summary.isFrozen -> 0.28f
        summary.completionPercent >= 90 -> 0.42f
        summary.completionPercent >= 65 -> 0.28f
        summary.completionPercent >= 35 -> 0.16f
        summary.completionPercent > 0 -> 0.09f
        else -> 0f
    }

    val baseFillColor = when {
        summary.isFrozen -> colors.freeze.copy(alpha = fillIntensity)
        fillIntensity > 0f -> colors.accent.copy(alpha = fillIntensity)
        else -> colors.surfaceElevated.copy(alpha = 0.45f)
    }

    val bgColor by animateColorAsState(targetValue = baseFillColor, label = "day_bg")

    val borderColor = when {
        isSelected -> colors.accent
        isToday -> colors.textPrimary.copy(alpha = 0.55f)
        else -> Color.Transparent
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(11.dp))
            .background(bgColor)
            .border(
                width = if (isSelected) 1.5.dp else if (isToday) 1.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(11.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = date.dayOfMonth.toString(),
                fontSize = 13.sp,
                fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Medium,
                color = colors.textPrimary
            )

            Spacer(Modifier.height(2.dp))

            if (summary.isFrozen) {
                Icon(
                    imageVector = Icons.Rounded.AcUnit,
                    contentDescription = "Заморожено",
                    tint = colors.freeze,
                    modifier = Modifier.size(9.dp)
                )
            } else {
                val dots = summary.sphereIds.take(3)
                if (dots.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        dots.forEach { sphereId ->
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .clip(CircleShape)
                                    .background(sphereColorMap[sphereId] ?: colors.accent)
                            )
                        }
                    }
                } else {
                    Spacer(Modifier.height(4.dp))
                }
            }
        }
    }
}
