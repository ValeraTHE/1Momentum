package com.momentum.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.momentum.app.data.AccentPreset
import com.momentum.app.data.AppSettings
import com.momentum.app.data.MomentumState
import com.momentum.app.data.Sphere
import com.momentum.app.data.SpherePalette
import com.momentum.app.ui.theme.LocalMomentumColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    state: MomentumState,
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onUpsertSphere: (String?, String, Long) -> Unit,
    onDeleteSphere: (String) -> Unit,
    onRestartSprint: () -> Unit,
    onExportJson: () -> String,
    onImportJson: (String) -> Boolean,
    onResetAll: () -> Unit
) {
    val colors = LocalMomentumColors.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var editingSphere by remember { mutableStateOf<Sphere?>(null) }
    var showSphereDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showSprintGoalDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "settings_title") {
            Text(
                text = "Настройки и сферы",
                style = MaterialTheme.typography.headlineSmall,
                color = colors.textPrimary
            )
        }

        item(key = "spheres_card") {
            SettingsCard(title = "Сферы и цветовые ассоциации") {
                state.spheres.forEachIndexed { index, sphere ->
                    if (index > 0) {
                        HorizontalDivider(color = colors.border, thickness = 1.dp)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(Color(sphere.colorHex))
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = sphere.name,
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                editingSphere = sphere
                                showSphereDialog = true
                            },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Edit,
                                contentDescription = "Изменить",
                                tint = colors.textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        if (state.spheres.size > 1) {
                            IconButton(
                                onClick = { onDeleteSphere(sphere.id) },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = "Удалить",
                                    tint = colors.danger.copy(alpha = 0.85f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    onClick = {
                        editingSphere = null
                        showSphereDialog = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = null,
                        tint = colors.accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Добавить сферу", color = colors.accent)
                }
            }
        }

        item(key = "visual_card") {
            SettingsCard(title = "Внешний вид и анти-шум") {
                ToggleRow(
                    title = "Тёмная OLED-тема",
                    subtitle = "Глубокий тёмный фон без бликов",
                    checked = state.settings.darkTheme,
                    onCheckedChange = { enabled -> onUpdateSettings { it.copy(darkTheme = enabled) } }
                )
                HorizontalDivider(color = colors.border)
                ToggleRow(
                    title = "XP и уровни (геймификация)",
                    subtitle = "Можно выключить для строгого трекера",
                    checked = state.settings.showXpAndLevels,
                    onCheckedChange = { enabled -> onUpdateSettings { it.copy(showXpAndLevels = enabled) } }
                )
                HorizontalDivider(color = colors.border)
                ToggleRow(
                    title = "Модуль «12-недельный год»",
                    subtitle = "Индекс недели и шкала спринта",
                    checked = state.settings.showSprintBar,
                    onCheckedChange = { enabled -> onUpdateSettings { it.copy(showSprintBar = enabled) } }
                )
                HorizontalDivider(color = colors.border)
                ToggleRow(
                    title = "Тактильный отклик (вибрация)",
                    subtitle = "Лёгкий импульс при отметке прогресса",
                    checked = state.settings.hapticEnabled,
                    onCheckedChange = { enabled -> onUpdateSettings { it.copy(hapticEnabled = enabled) } }
                )
                HorizontalDivider(color = colors.border)

                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Акцентный цвет",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AccentPreset.entries.forEach { preset ->
                        val selected = state.settings.accentPreset == preset
                        val swatchColor = if (!state.settings.darkTheme && preset == AccentPreset.MONOCHROME) {
                            Color(0xFF1E293B)
                        } else {
                            Color(preset.hex)
                        }
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(swatchColor)
                                .border(
                                    width = if (selected) 2.5.dp else 1.dp,
                                    color = if (selected) colors.textPrimary else colors.border,
                                    shape = CircleShape
                                )
                                .clickable {
                                    onUpdateSettings { it.copy(accentPreset = preset) }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (selected) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = preset.title,
                                    tint = if (preset == AccentPreset.MONOCHROME && state.settings.darkTheme) Color.Black else Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item(key = "rules_card") {
            SettingsCard(title = "Правила серии и спринта") {
                Text(
                    text = "Порог дня для зачёта серии",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary
                )
                Text(
                    text = "Минимальный процент плана, чтобы цепь не прервалась",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(50, 60, 70, 80, 100).forEach { threshold ->
                        val selected = state.settings.dailyStreakThresholdPercent == threshold
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) colors.accent else colors.surfaceElevated)
                                .clickable {
                                    onUpdateSettings { it.copy(dailyStreakThresholdPercent = threshold) }
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$threshold%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) colors.onAccent else colors.textSecondary
                            )
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = colors.border)
                Spacer(Modifier.height(10.dp))

                Text(
                    text = "Длина спринта",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(4, 8, 12).forEach { weeks ->
                        val selected = state.settings.sprintLengthWeeks == weeks
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) colors.accent else colors.surfaceElevated)
                                .clickable {
                                    onUpdateSettings { it.copy(sprintLengthWeeks = weeks) }
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$weeks нед.",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) colors.onAccent else colors.textSecondary
                            )
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showSprintGoalDialog = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Цель спринта", color = colors.textPrimary)
                    }
                    OutlinedButton(
                        onClick = onRestartSprint,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Новый старт", color = colors.accent)
                    }
                }
            }
        }

        item(key = "backup_card") {
            SettingsCard(title = "Резервная копия (JSON)") {
                Text(
                    text = "Сохраните JSON перед обновлением APK, чтобы перенести всю историю, сферы и серии.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val data = onExportJson()
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Моментум — резервная копия")
                                putExtra(Intent.EXTRA_TEXT, data)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Экспорт JSON"))
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colors.accent,
                            contentColor = colors.onAccent
                        )
                    ) {
                        Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Экспорт")
                    }

                    OutlinedButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(onExportJson()))
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Копировать", color = colors.textPrimary)
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showImportDialog = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Upload, contentDescription = null, tint = colors.accent, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Импорт JSON", color = colors.accent)
                    }

                    OutlinedButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Сбросить всё", color = colors.danger)
                    }
                }
            }
        }
    }

    if (showSphereDialog) {
        var name by remember(editingSphere) { mutableStateOf(editingSphere?.name ?: "") }
        var colorHex by remember(editingSphere) {
            mutableLongStateOf(editingSphere?.colorHex ?: SpherePalette.presets.first().second)
        }

        AlertDialog(
            onDismissRequest = { showSphereDialog = false },
            containerColor = colors.surface,
            titleContentColor = colors.textPrimary,
            title = { Text(if (editingSphere == null) "Новая сфера" else "Редактировать сферу") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Название сферы") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.accent,
                            unfocusedBorderColor = colors.border,
                            focusedTextColor = colors.textPrimary,
                            unfocusedTextColor = colors.textPrimary
                        )
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SpherePalette.presets.forEach { (_, hex) ->
                            val selected = colorHex == hex
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (selected) 2.5.dp else 0.dp,
                                        color = colors.textPrimary,
                                        shape = CircleShape
                                    )
                                    .clickable { colorHex = hex },
                                contentAlignment = Alignment.Center
                            ) {
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (name.trim().isNotEmpty()) {
                            onUpsertSphere(editingSphere?.id, name, colorHex)
                            showSphereDialog = false
                        }
                    }
                ) {
                    Text("Сохранить", color = colors.accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSphereDialog = false }) {
                    Text("Отмена", color = colors.textSecondary)
                }
            }
        )
    }

    if (showSprintGoalDialog) {
        var draftGoal by remember(state.settings.sprintGoalTitle) { mutableStateOf(state.settings.sprintGoalTitle) }
        AlertDialog(
            onDismissRequest = { showSprintGoalDialog = false },
            containerColor = colors.surface,
            titleContentColor = colors.textPrimary,
            title = { Text("Главный фокус спринта") },
            text = {
                OutlinedTextField(
                    value = draftGoal,
                    onValueChange = { draftGoal = it },
                    label = { Text("Название цели") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = draftGoal.trim().ifEmpty { "Главный фокус спринта" }
                    onUpdateSettings { it.copy(sprintGoalTitle = clean) }
                    showSprintGoalDialog = false
                }) {
                    Text("Сохранить", color = colors.accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSprintGoalDialog = false }) {
                    Text("Отмена", color = colors.textSecondary)
                }
            }
        )
    }

    if (showImportDialog) {
        var rawJson by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = colors.surface,
            titleContentColor = colors.textPrimary,
            title = { Text("Восстановление из JSON") },
            text = {
                OutlinedTextField(
                    value = rawJson,
                    onValueChange = { rawJson = it },
                    placeholder = { Text("Вставьте скопированный JSON сюда...") },
                    minLines = 5,
                    maxLines = 10,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (onImportJson(rawJson)) {
                        showImportDialog = false
                    }
                }) {
                    Text("Восстановить", color = colors.accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Отмена", color = colors.textSecondary)
                }
            }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            containerColor = colors.surface,
            titleContentColor = colors.textPrimary,
            textContentColor = colors.textSecondary,
            title = { Text("Сбросить все данные?") },
            text = { Text("Все привычки, задачи, события и история серий будут удалены. Рекомендуем сначала сделать экспорт JSON.") },
            confirmButton = {
                TextButton(onClick = {
                    onResetAll()
                    showResetDialog = false
                }) {
                    Text("Сбросить", color = colors.danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Отмена", color = colors.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    val colors = LocalMomentumColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = colors.textPrimary
        )
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = LocalMomentumColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.onAccent,
                checkedTrackColor = colors.accent
            )
        )
    }
}
