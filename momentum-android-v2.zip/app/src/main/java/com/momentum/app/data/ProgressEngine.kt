package com.momentum.app.data

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class DaySummary(
    val date: LocalDate,
    val earnedXp: Int,
    val targetXp: Int,
    val completionPercent: Int,
    val completedItems: Int,
    val totalItems: Int,
    val sphereIds: List<String>,
    val isFrozen: Boolean
)

data class LevelInfo(
    val level: Int,
    val rankTitle: String,
    val currentLevelXp: Int,
    val xpForNextLevel: Int,
    val totalEarnedXp: Int,
    val availableXp: Int
) {
    val progress: Float
        get() = if (xpForNextLevel <= 0) 0f else (currentLevelXp.toFloat() / xpForNextLevel.toFloat()).coerceIn(0f, 1f)
}

data class SprintStats(
    val currentWeek: Int,
    val totalWeeks: Int,
    val daysRemaining: Int,
    val sprintExecutionPercent: Int,
    val currentWeekExecutionPercent: Int
)

data class SphereStat(
    val sphere: Sphere,
    val completedCount: Int,
    val earnedXp: Int,
    val sharePercent: Int
)

object ProgressEngine {

    private val rankTitles = listOf(
        "Старт",
        "Ритм",
        "Импульс",
        "Фокус",
        "Система",
        "Поток",
        "Монолит",
        "Мастер",
        "Доминант"
    )

    fun safeParseDate(raw: String?): LocalDate? {
        if (raw.isNullOrBlank()) return null
        return try {
            LocalDate.parse(raw)
        } catch (_: Exception) {
            null
        }
    }

    fun scheduledHabitsForDate(state: MomentumState, date: LocalDate): List<Habit> {
        val dow = date.dayOfWeek.value
        return state.habits.filter { habit ->
            if (habit.archived) return@filter false
            val created = safeParseDate(habit.createdDate) ?: LocalDate.MIN
            val hasLogged = state.dayRecords[date.toString()]?.habitCompletions?.containsKey(habit.id) == true
            (dow in habit.daysOfWeek && !date.isBefore(created)) || hasLogged
        }
    }

    fun calculateDaySummary(state: MomentumState, date: LocalDate): DaySummary {
        val dateStr = date.toString()
        val record = state.dayRecords[dateStr]
        val isFrozen = dateStr in state.frozenDates

        val habits = scheduledHabitsForDate(state, date)
        val dayTasks = state.tasks.filter { it.date == dateStr || (it.date == null && it.completedDate == dateStr) }
        val dayEvents = state.events.filter { it.date == dateStr }

        var earnedXp = 0
        var targetXp = 0
        var completedItems = 0
        var totalItems = 0
        val sphereIds = linkedSetOf<String>()

        for (habit in habits) {
            val tier = record?.habitCompletions?.get(habit.id) ?: HabitTier.NONE
            targetXp += habit.xpBase
            earnedXp += habit.xpFor(tier)
            totalItems += 1
            if (tier != HabitTier.NONE) completedItems += 1
            sphereIds.add(habit.sphereId)
        }

        for (task in dayTasks) {
            targetXp += task.xpReward
            totalItems += 1
            if (task.isCompleted) {
                earnedXp += task.xpReward
                completedItems += 1
            }
            sphereIds.add(task.sphereId)
        }

        for (event in dayEvents) {
            targetXp += event.xpReward
            totalItems += 1
            if (event.isCompleted) {
                earnedXp += event.xpReward
                completedItems += 1
            }
            sphereIds.add(event.sphereId)
        }

        val percent = when {
            targetXp > 0 -> ((earnedXp.toFloat() / targetXp.toFloat()) * 100f).roundToInt().coerceIn(0, 100)
            completedItems > 0 -> 100
            else -> 0
        }

        return DaySummary(
            date = date,
            earnedXp = earnedXp,
            targetXp = targetXp,
            completionPercent = percent,
            completedItems = completedItems,
            totalItems = totalItems,
            sphereIds = sphereIds.toList(),
            isFrozen = isFrozen
        )
    }

    fun calculateTotalEarnedXp(state: MomentumState): Int {
        val habitMap = state.habits.associateBy { it.id }
        var total = 0

        for ((_, record) in state.dayRecords) {
            for ((habitId, tier) in record.habitCompletions) {
                val habit = habitMap[habitId]
                total += habit?.xpFor(tier) ?: when (tier) {
                    HabitTier.NONE -> 0
                    HabitTier.MIN -> 10
                    HabitTier.BASE -> 25
                    HabitTier.MAX -> 50
                }
            }
        }

        for (task in state.tasks) {
            if (task.isCompleted) total += task.xpReward
        }

        for (event in state.events) {
            if (event.isCompleted) total += event.xpReward
        }

        return total
    }

    fun calculateLevelInfo(state: MomentumState): LevelInfo {
        val totalXp = calculateTotalEarnedXp(state)
        val availableXp = max(0, totalXp - state.spentXp)

        var level = 1
        var remaining = totalXp
        var needed = 150

        while (remaining >= needed) {
            remaining -= needed
            level += 1
            needed = 150 + (level - 1) * 50
        }

        val rankIndex = min(rankTitles.lastIndex, (level - 1) / 2)
        return LevelInfo(
            level = level,
            rankTitle = rankTitles[rankIndex],
            currentLevelXp = remaining,
            xpForNextLevel = needed,
            totalEarnedXp = totalXp,
            availableXp = availableXp
        )
    }

    fun isDayQualifiedForStreak(state: MomentumState, date: LocalDate): Boolean {
        val summary = calculateDaySummary(state, date)
        if (summary.isFrozen) return true
        return summary.totalItems > 0 && summary.completionPercent >= state.settings.dailyStreakThresholdPercent
    }

    fun calculateCurrentStreak(state: MomentumState, today: LocalDate = LocalDate.now()): Int {
        var cursor = if (isDayQualifiedForStreak(state, today)) today else today.minusDays(1)
        var streak = 0
        var guard = 0
        while (guard < 3650 && isDayQualifiedForStreak(state, cursor)) {
            streak += 1
            cursor = cursor.minusDays(1)
            guard += 1
        }
        return streak
    }

    fun calculateBestStreak(state: MomentumState, today: LocalDate = LocalDate.now()): Int {
        val allDates = buildSet {
            state.dayRecords.keys.mapNotNullTo(this) { safeParseDate(it) }
            state.tasks.mapNotNullTo(this) { safeParseDate(it.date) }
            state.tasks.mapNotNullTo(this) { safeParseDate(it.completedDate) }
            state.events.mapNotNullTo(this) { safeParseDate(it.date) }
            state.frozenDates.mapNotNullTo(this) { safeParseDate(it) }
        }
        if (allDates.isEmpty()) return calculateCurrentStreak(state, today)

        val earliest = allDates.minBy { it.toEpochDay() }
        val latestRecord = allDates.maxBy { it.toEpochDay() }
        val end = if (today.isAfter(latestRecord)) today else latestRecord

        var best = 0
        var running = 0
        var cursor = earliest
        var guard = 0
        while (!cursor.isAfter(end) && guard < 3650) {
            if (isDayQualifiedForStreak(state, cursor)) {
                running += 1
                if (running > best) best = running
            } else {
                running = 0
            }
            cursor = cursor.plusDays(1)
            guard += 1
        }
        return best
    }

    fun calculateHabitStreak(state: MomentumState, habit: Habit, today: LocalDate = LocalDate.now()): Int {
        var streak = 0
        var cursor = today
        var guard = 0
        val created = safeParseDate(habit.createdDate) ?: today.minusYears(1)

        val todayScheduled = today.dayOfWeek.value in habit.daysOfWeek
        val todayTier = state.dayRecords[today.toString()]?.habitCompletions?.get(habit.id) ?: HabitTier.NONE
        if (todayScheduled && todayTier == HabitTier.NONE) {
            cursor = today.minusDays(1)
        }

        while (guard < 730 && !cursor.isBefore(created.minusDays(30))) {
            val isScheduled = cursor.dayOfWeek.value in habit.daysOfWeek
            val tier = state.dayRecords[cursor.toString()]?.habitCompletions?.get(habit.id) ?: HabitTier.NONE
            if (tier != HabitTier.NONE) {
                streak += 1
            } else if (isScheduled) {
                if (cursor.toString() !in state.frozenDates) {
                    break
                }
            }
            cursor = cursor.minusDays(1)
            guard += 1
        }
        return streak
    }

    fun calculateWeekExecutionPercent(state: MomentumState, referenceDate: LocalDate = LocalDate.now()): Int {
        val monday = referenceDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        var earned = 0
        var target = 0
        for (i in 0..6) {
            val summary = calculateDaySummary(state, monday.plusDays(i.toLong()))
            earned += summary.earnedXp
            target += summary.targetXp
        }
        if (target <= 0) return 0
        return ((earned.toFloat() / target.toFloat()) * 100f).roundToInt().coerceIn(0, 100)
    }

    fun calculateSprintStats(state: MomentumState, today: LocalDate = LocalDate.now()): SprintStats {
        val start = safeParseDate(state.settings.sprintStartDate)
            ?: today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val totalWeeks = state.settings.sprintLengthWeeks.coerceIn(1, 52)
        val totalDays = totalWeeks * 7L
        val sprintEnd = start.plusDays(totalDays - 1)

        val daysElapsed = ChronoUnit.DAYS.between(start, today).coerceAtLeast(0)
        val currentWeek = ((daysElapsed / 7L).toInt() + 1).coerceIn(1, totalWeeks)
        val daysRemaining = ChronoUnit.DAYS.between(today, sprintEnd).coerceAtLeast(0).toInt()

        var earned = 0
        var target = 0
        val evalEnd = if (today.isBefore(sprintEnd)) today else sprintEnd
        var cursor = start
        var guard = 0
        while (!cursor.isAfter(evalEnd) && guard < 400) {
            val summary = calculateDaySummary(state, cursor)
            earned += summary.earnedXp
            target += summary.targetXp
            cursor = cursor.plusDays(1)
            guard += 1
        }

        val sprintPercent = if (target <= 0) 0 else ((earned.toFloat() / target.toFloat()) * 100f).roundToInt().coerceIn(0, 100)
        val weekPercent = calculateWeekExecutionPercent(state, today)

        return SprintStats(
            currentWeek = currentWeek,
            totalWeeks = totalWeeks,
            daysRemaining = daysRemaining,
            sprintExecutionPercent = sprintPercent,
            currentWeekExecutionPercent = weekPercent
        )
    }

    fun calculateSphereBreakdown(state: MomentumState): List<SphereStat> {
        val habitMap = state.habits.associateBy { it.id }
        val countBySphere = mutableMapOf<String, Int>()
        val xpBySphere = mutableMapOf<String, Int>()

        for ((_, record) in state.dayRecords) {
            for ((habitId, tier) in record.habitCompletions) {
                if (tier == HabitTier.NONE) continue
                val habit = habitMap[habitId] ?: continue
                countBySphere[habit.sphereId] = (countBySphere[habit.sphereId] ?: 0) + 1
                xpBySphere[habit.sphereId] = (xpBySphere[habit.sphereId] ?: 0) + habit.xpFor(tier)
            }
        }

        for (task in state.tasks) {
            if (!task.isCompleted) continue
            countBySphere[task.sphereId] = (countBySphere[task.sphereId] ?: 0) + 1
            xpBySphere[task.sphereId] = (xpBySphere[task.sphereId] ?: 0) + task.xpReward
        }

        for (event in state.events) {
            if (!event.isCompleted) continue
            countBySphere[event.sphereId] = (countBySphere[event.sphereId] ?: 0) + 1
            xpBySphere[event.sphereId] = (xpBySphere[event.sphereId] ?: 0) + event.xpReward
        }

        val totalXp = xpBySphere.values.sum()
        return state.spheres.map { sphere ->
            val xp = xpBySphere[sphere.id] ?: 0
            val count = countBySphere[sphere.id] ?: 0
            val share = if (totalXp > 0) ((xp.toFloat() / totalXp.toFloat()) * 100f).roundToInt() else 0
            SphereStat(
                sphere = sphere,
                completedCount = count,
                earnedXp = xp,
                sharePercent = share
            )
        }.sortedByDescending { it.earnedXp }
    }

    fun canFreezeYesterday(state: MomentumState, today: LocalDate = LocalDate.now()): Boolean {
        val yesterday = today.minusDays(1)
        val yesterdayStr = yesterday.toString()
        if (state.freezeTokens <= 0) return false
        if (yesterdayStr in state.frozenDates) return false
        return !isDayQualifiedForStreak(state, yesterday)
    }
}
