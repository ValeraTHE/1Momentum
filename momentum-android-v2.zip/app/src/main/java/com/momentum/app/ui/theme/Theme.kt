package com.momentum.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.momentum.app.data.AccentPreset

@Immutable
data class MomentumColors(
    val background: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val onAccent: Color,
    val freeze: Color,
    val flame: Color,
    val danger: Color,
    val isDark: Boolean
)

val LocalMomentumColors = staticCompositionLocalOf {
    MomentumColors(
        background = Color(0xFF0B0D10),
        surface = Color(0xFF14181F),
        surfaceElevated = Color(0xFF1B212B),
        border = Color(0xFF242C38),
        textPrimary = Color(0xFFF3F5F8),
        textSecondary = Color(0xFF8E98A8),
        accent = Color(0xFF10B981),
        onAccent = Color(0xFF04130D),
        freeze = Color(0xFF38BDF8),
        flame = Color(0xFFF59E0B),
        danger = Color(0xFFF43F5E),
        isDark = true
    )
}

private val MomentumTypography = Typography(
    headlineSmall = TextStyle(
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-0.3).sp
    ),
    titleLarge = TextStyle(
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = (-0.2).sp
    ),
    titleMedium = TextStyle(
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold
    ),
    bodyMedium = TextStyle(
        fontSize = 14.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 20.sp
    ),
    bodySmall = TextStyle(
        fontSize = 12.sp,
        fontWeight = FontWeight.Normal,
        lineHeight = 16.sp
    ),
    labelMedium = TextStyle(
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 0.2.sp
    ),
    labelSmall = TextStyle(
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 0.3.sp
    )
)

@Composable
fun MomentumTheme(
    darkTheme: Boolean,
    accentPreset: AccentPreset,
    content: @Composable () -> Unit
) {
    val accentColor = if (!darkTheme && accentPreset == AccentPreset.MONOCHROME) {
        Color(0xFF1E293B)
    } else {
        Color(accentPreset.hex)
    }

    val onAccentColor = when {
        !darkTheme && accentPreset == AccentPreset.MONOCHROME -> Color.White
        accentPreset == AccentPreset.MONOCHROME || accentPreset == AccentPreset.AMBER || accentPreset == AccentPreset.EMERALD -> Color(0xFF090D11)
        else -> Color.White
    }

    val customColors = if (darkTheme) {
        MomentumColors(
            background = Color(0xFF0B0D10),
            surface = Color(0xFF14181F),
            surfaceElevated = Color(0xFF1B212B),
            border = Color(0xFF242C38),
            textPrimary = Color(0xFFF3F5F8),
            textSecondary = Color(0xFF8E98A8),
            accent = accentColor,
            onAccent = onAccentColor,
            freeze = Color(0xFF38BDF8),
            flame = Color(0xFFF59E0B),
            danger = Color(0xFFF43F5E),
            isDark = true
        )
    } else {
        MomentumColors(
            background = Color(0xFFF4F6FA),
            surface = Color(0xFFFFFFFF),
            surfaceElevated = Color(0xFFEDF1F7),
            border = Color(0xFFDCE3EE),
            textPrimary = Color(0xFF0F172A),
            textSecondary = Color(0xFF5B667A),
            accent = accentColor,
            onAccent = onAccentColor,
            freeze = Color(0xFF0284C7),
            flame = Color(0xFFD97706),
            danger = Color(0xFFE11D48),
            isDark = false
        )
    }

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = customColors.accent,
            onPrimary = customColors.onAccent,
            background = customColors.background,
            onBackground = customColors.textPrimary,
            surface = customColors.surface,
            onSurface = customColors.textPrimary,
            surfaceVariant = customColors.surfaceElevated,
            onSurfaceVariant = customColors.textSecondary,
            outline = customColors.border,
            error = customColors.danger
        )
    } else {
        lightColorScheme(
            primary = customColors.accent,
            onPrimary = customColors.onAccent,
            background = customColors.background,
            onBackground = customColors.textPrimary,
            surface = customColors.surface,
            onSurface = customColors.textPrimary,
            surfaceVariant = customColors.surfaceElevated,
            onSurfaceVariant = customColors.textSecondary,
            outline = customColors.border,
            error = customColors.danger
        )
    }

    CompositionLocalProvider(LocalMomentumColors provides customColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = MomentumTypography,
            content = content
        )
    }
}
