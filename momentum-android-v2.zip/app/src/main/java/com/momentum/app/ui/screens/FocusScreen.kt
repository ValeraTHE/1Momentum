package com.momentum.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.app.data.EventItem
import com.momentum.app.data.Habit
import com.momentum.app.data.HabitTier
import com.momentum.app.data.MomentumState
import com.momentum.app.data.ProgressEngine
import com.momentum.app.data.Sphere
import com.momentum.app.data.TaskItem
import com.momentum.app.ui.components.CalendarSection
import com.momentum.app.ui.components.EditorTarget
import com.momentum.app.ui.theme.LocalMomentumColors
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun FocusScreen(
    state: MomentumState,
    selectedDate: LocalDate,
    visibleMonth: YearMonth,
    onSelectDate: (LocalDate) -> Unit,
    onShiftMonth: (Long) -> Unit,
    onJumpToday: () -> Unit,
    onSetHabitTier: (String, LocalDate, HabitTier) -> Unit,
    onToggleBinaryHabit: (String, LocalDate) -> Unit,
    onToggleTask: (String, LocalDate) -> Unit,
    onToggleEvent: (String) -> Unit,
    onSaveDayNote: (LocalDate, String) -> Unit,
    onOpenEditor: (EditorTarget) -> Unit
) {
    val colors = LocalMomentumColors.current
    val haptic = LocalHapticFeedback.current
    val today = LocalDate.now()
    var isMonthExpanded by rememberSaveable { mutableStateOf(false) }
    var showNoteDialog by remember { mutableStateOf(false) }

    val sphereMap = remember(state.spheres) { state.spheres.associateBy { it.id } }
    val dateStr = selectedDate.toString()

    val levelInfo = remember(state) { ProgressEngine.calculateLevelInfo(state) }
    val currentStreak = remember(state, today) { ProgressEngine.calculateCurrentStreak(state, today) }
    val weekIndex = remember(state, selectedDate) { ProgressEngine.calculateWeekExecutionPercent(state, selectedDate) }
    val daySummary = remember(state, selectedDate) { ProgressEngine.calculateDaySummary(state, selectedDate) }

    val dayEvents = remember(state.events, dateStr) {
        state.events.filter { it.date == dateStr }.sortedBy { it.time.ifBlank { "99:99" } }
    }
    val dayHabits = remember(state.habits, state.dayRecords, selectedDate) {
        ProgressEngine.scheduledHabitsForDate(state, selectedDate)
    }
    val dayTasks = remember(state.tasks, dateStr) {
        state.tasks
            .filter { it.date == dateStr }
            .sortedWith(compareBy<TaskItem> { it.isCompleted }.thenByDescending { it.priority })
    }
    val backlogTasks = remember(state.tasks, dateStr) {
        state.tasks
            .filter { it.date == null && (!it.isCompleted || it.completedDate == dateStr) }
            .sortedWith(compareBy<TaskItem> { it.isCompleted }.thenByDescending { it.priority })
    }

    val dayRecord = state.dayRecords[dateStr]
    val dayNote = dayRecord?.note.orEmpty()

    fun triggerHaptic(strong: Boolean = false) {
        if (state.settings.hapticEnabled) {
            haptic.performHapticFeedback(
                if (strong) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
            )
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "header") {
            TelemetryHeader(
                showXp = state.settings.showXpAndLevels,
                showSprint = state.settings.showSprintBar,
                level = levelInfo.level,
                rankTitle = levelInfo.rankTitle,
                currentXp = levelInfo.currentLevelXp,
                nextXp = levelInfo.xpForNextLevel,
                levelProgress = levelInfo.progress,
                streak = currentStreak,
                freezeTokens = state.freezeTokens,
                weekIndex = weekIndex
            )
        }

        item(key = "calendar") {
            CalendarSection(
                state = state,
                selectedDate = selectedDate,
                visibleMonth = visibleMonth,
                isMonthExpanded = isMonthExpanded,
                onToggleExpand = { isMonthExpanded = !isMonthExpanded },
                onSelectDate = onSelectDate,
                onShiftMonth = onShiftMonth,
                onJumpToday = onJumpToday
            )
        }

        item(key = "day_summary") {
            DayExecutionBanner(
                selectedDate = selectedDate,
                completionPercent = daySummary.completionPercent,
                earnedXp = daySummary.earnedXp,
                targetXp = daySummary.targetXp,
                isFrozen = daySummary.isFrozen,
                showXp = state.settings.showXpAndLevels
            )
        }

        if (dayEvents.isNotEmpty()) {
            item(key = "events_header") {
                SectionLabel(title = "События дня", count = dayEvents.size)
            }
            items(dayEvents, key = { "event_${it.id}" }) { event ->
                EventCard(
                    event = event,
                    sphere = sphereMap[event.sphereId],
                    showXp = state.settings.showXpAndLevels,
                    onToggle = {
                        triggerHaptic(strong = !event.isCompleted)
                        onToggleEvent(event.id)
                    },
                    onEdit = { onOpenEditor(EditorTarget.EditEvent(event)) }
                )
            }
        }

        if (dayHabits.isNotEmpty()) {
            item(key = "habits_header") {
                SectionLabel(title = "Привычки и ритм", count = dayHabits.size)
            }
            items(dayHabits, key = { "habit_${it.id}" }) { habit ->
                val tier = dayRecord?.habitCompletions?.get(habit.id) ?: HabitTier.NONE
                val habitStreak = ProgressEngine.calculateHabitStreak(state, habit, today)
                HabitCard(
                    habit = habit,
                    sphere = sphereMap[habit.sphereId],
                    currentTier = tier,
                    streak = habitStreak,
                    showXp = state.settings.showXpAndLevels,
                    onSelectTier = { newTier ->
                        val finalTier = if (newTier == tier) HabitTier.NONE else newTier
                        triggerHaptic(strong = finalTier != HabitTier.NONE)
                        onSetHabitTier(habit.id, selectedDate, finalTier)
                    },
                    onToggleBinary = {
                        triggerHaptic(strong = tier == HabitTier.NONE)
                        onToggleBinaryHabit(habit.id, selectedDate)
                    },
                    onEdit = { onOpenEditor(EditorTarget.EditHabit(habit)) }
                )
            }
        }

        if (dayTasks.isNotEmpty()) {
            item(key = "tasks_header") {
                SectionLabel(title = "Задачи на день", count = dayTasks.size)
            }
            items(dayTasks, key = { "task_${it.id}" }) { task ->
                TaskCard(
                    task = task,
                    sphere = sphereMap[task.sphereId],
                    showXp = state.settings.showXpAndLevels,
                    onToggle = {
                        triggerHaptic(strong = !task.isCompleted)
                        onToggleTask(task.id, selectedDate)
                    },
                    onEdit = { onOpenEditor(EditorTarget.EditTask(task)) }
                )
            }
        }

        if (backlogTasks.isNotEmpty()) {
            item(key = "backlog_header") {
                SectionLabel(title = "Без даты (Бэклог)", count = backlogTasks.size)
            }
            items(backlogTasks, key = { "backlog_${it.id}" }) { task ->
                TaskCard(
                    task = task,
                    sphere = sphereMap[task.sphereId],
                    showXp = state.settings.showXpAndLevels,
                    onToggle = {
                        triggerHaptic(strong = !task.isCompleted)
                        onToggleTask(task.id, selectedDate)
                    },
                    onEdit = { onOpenEditor(EditorTarget.EditTask(task)) }
                )
            }
        }

        if (dayEvents.isEmpty() && dayHabits.isEmpty() && dayTasks.isEmpty() && backlogTasks.isEmpty()) {
            item(key = "empty_day") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(colors.surface)
                        .border(1.dp, colors.border, RoundedCornerShape(16.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "На этот день пока ничего не запланировано.\nНажми «+» внизу, чтобы добавить задачу, привычку или событие.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )
                }
            }
        }

        item(key = "day_note") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.border, RoundedCornerShape(14.dp))
                    .clickable { showNoteDialog = true }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Итог дня",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textSecondary
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = dayNote.ifBlank { "Зафиксировать главную мысль или вывод дня..." },
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (dayNote.isBlank()) colors.textSecondary.copy(alpha = 0.65f) else colors.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = "Редактировать заметку",
                    tint = colors.textSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }

    if (showNoteDialog) {
        var draft by remember(dateStr, dayNote) { mutableStateOf(dayNote) }
        AlertDialog(
            onDismissRequest = { showNoteDialog = false },
            containerColor = colors.surface,
            titleContentColor = colors.textPrimary,
            textContentColor = colors.textPrimary,
            title = { Text("Итог дня ($dateStr)") },
            text = {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    placeholder = { Text("Что сработало хорошо? Что улучшить завтра?") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onSaveDayNote(selectedDate, draft)
                    showNoteDialog = false
                }) {
                    Text("Сохранить", color = colors.accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNoteDialog = false }) {
                    Text("Отмена", color = colors.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun TelemetryHeader(
    showXp: Boolean,
    showSprint: Boolean,
    level: Int,
    rankTitle: String,
    currentXp: Int,
    nextXp: Int,
    levelProgress: Float,
    streak: Int,
    freezeTokens: Int,
    weekIndex: Int
) {
    val colors = LocalMomentumColors.current
    val animatedProgress by animateFloatAsState(targetValue = levelProgress, label = "xp_bar")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "МОМЕНТУМ",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.accent,
                    letterSpacing = 1.4.sp
                )
                Text(
                    text = if (showXp) "Ур. $level • $rankTitle" else "Трекер ритма",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.textPrimary
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(colors.flame.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocalFireDepartment,
                        contentDescription = "Серия",
                        tint = colors.flame,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        text = "$streak",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.flame
                    )
                }

                if (freezeTokens > 0) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.freeze.copy(alpha = 0.14f))
                            .padding(horizontal = 9.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AcUnit,
                            contentDescription = "Жетоны заморозки",
                            tint = colors.freeze,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(3.dp))
                        Text(
                            text = "$freezeTokens",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.freeze
                        )
                    }
                }

                if (showSprint) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.surfaceElevated)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Нед. $weekIndex%",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (weekIndex >= 85) colors.accent else colors.textPrimary
                        )
                    }
                }
            }
        }

        if (showXp) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Прогресс уровня",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                    Text(
                        text = "$currentXp / $nextXp XP",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(6.dp)),
                    color = colors.accent,
                    trackColor = colors.surfaceElevated,
                    strokeCap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
private fun DayExecutionBanner(
    selectedDate: LocalDate,
    completionPercent: Int,
    earnedXp: Int,
    targetXp: Int,
    isFrozen: Boolean,
    showXp: Boolean
) {
    val colors = LocalMomentumColors.current
    val ruLocale = remember { Locale.forLanguageTag("ru") }
    val formatter = remember(ruLocale) { DateTimeFormatter.ofPattern("d MMMM, EEEE", ruLocale) }
    val dateTitle = remember(selectedDate) {
        val raw = selectedDate.format(formatter)
        raw.replaceFirstChar { if (it.isLowerCase()) it.titlecase(ruLocale) else it.toString() }
    }
    val progress by animateFloatAsState(
        targetValue = (completionPercent / 100f).coerceIn(0f, 1f),
        label = "day_progress"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = dateTitle,
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isFrozen) {
                    Icon(
                        imageVector = Icons.Rounded.AcUnit,
                        contentDescription = null,
                        tint = colors.freeze,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    text = if (showXp) "$completionPercent% • $earnedXp/$targetXp XP" else "$completionPercent%",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (completionPercent >= 80) colors.accent else colors.textSecondary
                )
            }
        }

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(RoundedCornerShape(5.dp)),
            color = if (isFrozen) colors.freeze else colors.accent,
            trackColor = colors.surfaceElevated,
            strokeCap = StrokeCap.Round
        )
    }
}

@Composable
private fun SectionLabel(title: String, count: Int) {
    val colors = LocalMomentumColors.current
    val ruLocale = remember { Locale.forLanguageTag("ru") }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp, start = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title.uppercase(ruLocale),
            style = MaterialTheme.typography.labelSmall,
            color = colors.textSecondary,
            letterSpacing = 1.sp
        )
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.labelSmall,
            color = colors.textSecondary
        )
    }
}

@Composable
private fun EventCard(
    event: EventItem,
    sphere: Sphere?,
    showXp: Boolean,
    onToggle: () -> Unit,
    onEdit: () -> Unit
) {
    val colors = LocalMomentumColors.current
    val sphereColor = sphere?.let { Color(it.colorHex) } ?: colors.accent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.surface)
            .border(1.dp, if (event.isCompleted) sphereColor.copy(alpha = 0.4f) else colors.border, RoundedCornerShape(14.dp))
            .clickable { onEdit() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(34.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(sphereColor)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (event.time.isNotBlank()) {
                    Icon(
                        imageVector = Icons.Rounded.Schedule,
                        contentDescription = null,
                        tint = sphereColor,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = event.time,
                        style = MaterialTheme.typography.labelMedium,
                        color = sphereColor
                    )
                    Spacer(Modifier.width(8.dp))
                }
                if (sphere != null) {
                    Text(
                        text = sphere.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text = event.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = if (event.isCompleted) colors.textSecondary else colors.textPrimary,
                textDecoration = if (event.isCompleted) TextDecoration.LineThrough else TextDecoration.None
            )
            if (event.note.isNotBlank()) {
                Text(
                    text = event.note,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (showXp) {
            Text(
                text = "+${event.xpReward}",
                style = MaterialTheme.typography.labelSmall,
                color = if (event.isCompleted) sphereColor else colors.textSecondary
            )
            Spacer(Modifier.width(8.dp))
        }
        Icon(
            imageVector = if (event.isCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
            contentDescription = "Отметить событие",
            tint = if (event.isCompleted) sphereColor else colors.textSecondary,
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .clickable { onToggle() }
        )
    }
}

@Composable
private fun HabitCard(
    habit: Habit,
    sphere: Sphere?,
    currentTier: HabitTier,
    streak: Int,
    showXp: Boolean,
    onSelectTier: (HabitTier) -> Unit,
    onToggleBinary: () -> Unit,
    onEdit: () -> Unit
) {
    val colors = LocalMomentumColors.current
    val sphereColor = sphere?.let { Color(it.colorHex) } ?: colors.accent
    val isDone = currentTier != HabitTier.NONE

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(15.dp))
            .background(colors.surface)
            .border(
                width = 1.dp,
                color = if (isDone) sphereColor.copy(alpha = 0.5f) else colors.border,
                shape = RoundedCornerShape(15.dp)
            )
            .clickable { onEdit() }
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(sphereColor)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = habit.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (sphere != null) {
                        Text(
                            text = sphere.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary
                        )
                    }
                    if (streak > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.LocalFireDepartment,
                                contentDescription = null,
                                tint = colors.flame,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "$streak дн.",
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.flame
                            )
                        }
                    }
                }
            }

            if (!habit.isElastic) {
                if (showXp) {
                    Text(
                        text = "+${habit.xpBase}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isDone) sphereColor else colors.textSecondary
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (isDone) sphereColor else colors.surfaceElevated)
                        .clickable { onToggleBinary() },
                    contentAlignment = Alignment.Center
                ) {
                    if (isDone) {
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Выполнено",
                            tint = Color(0xFF090D11),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            } else if (showXp && isDone) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(sphereColor.copy(alpha = 0.16f))
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Bolt,
                        contentDescription = null,
                        tint = sphereColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "+${habit.xpFor(currentTier)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = sphereColor
                    )
                }
            }
        }

        if (habit.isElastic) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Triple(HabitTier.MIN, habit.minLabel, habit.xpMin),
                    Triple(HabitTier.BASE, habit.baseLabel, habit.xpBase),
                    Triple(HabitTier.MAX, habit.maxLabel, habit.xpMax)
                ).forEach { (tier, subLabel, xp) ->
                    val selected = currentTier == tier
                    val bg by animateColorAsState(
                        targetValue = if (selected) sphereColor.copy(alpha = 0.24f) else colors.surfaceElevated,
                        label = "tier_bg"
                    )
                    val border by animateColorAsState(
                        targetValue = if (selected) sphereColor else Color.Transparent,
                        label = "tier_border"
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(bg)
                            .border(1.dp, border, RoundedCornerShape(10.dp))
                            .clickable { onSelectTier(tier) }
                            .padding(vertical = 7.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = tier.label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) colors.textPrimary else colors.textSecondary
                        )
                        Text(
                            text = if (showXp) "$subLabel • $xp" else subLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (selected) sphereColor else colors.textSecondary.copy(alpha = 0.75f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskCard(
    task: TaskItem,
    sphere: Sphere?,
    showXp: Boolean,
    onToggle: () -> Unit,
    onEdit: () -> Unit
) {
    val colors = LocalMomentumColors.current
    val sphereColor = sphere?.let { Color(it.colorHex) } ?: colors.accent
    val priorityLabel = when (task.priority) {
        3 -> "Ключевая"
        2 -> "Важная"
        else -> null
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.surface)
            .border(1.dp, if (task.isCompleted) colors.border.copy(alpha = 0.6f) else colors.border, RoundedCornerShape(14.dp))
            .clickable { onEdit() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (task.isCompleted) sphereColor else colors.surfaceElevated)
                .border(
                    width = 1.5.dp,
                    color = if (task.isCompleted) sphereColor else sphereColor.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(8.dp)
                )
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (task.isCompleted) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = "Выполнено",
                    tint = Color(0xFF090D11),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = task.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = if (task.isCompleted) colors.textSecondary else colors.textPrimary,
                textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
            )
            if (task.note.isNotBlank()) {
                Text(
                    text = task.note,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(3.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (sphere != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(sphereColor)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = sphere.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textSecondary
                        )
                    }
                }
                if (priorityLabel != null) {
                    Text(
                        text = priorityLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (task.priority == 3) colors.danger else colors.flame
                    )
                }
            }
        }

        if (showXp) {
            Text(
                text = "+${task.xpReward}",
                style = MaterialTheme.typography.labelSmall,
                color = if (task.isCompleted) sphereColor else colors.textSecondary
            )
        }
    }
}
