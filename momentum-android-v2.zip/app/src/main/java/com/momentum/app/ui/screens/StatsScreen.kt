package com.momentum.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.momentum.app.data.MomentumState
import com.momentum.app.data.ProgressEngine
import com.momentum.app.ui.theme.LocalMomentumColors
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

@Composable
fun StatsScreen(
    state: MomentumState,
    onBuyFreezeToken: () -> Unit,
    onFreezeDate: (LocalDate) -> Unit,
    onOpenDay: (LocalDate) -> Unit
) {
    val colors = LocalMomentumColors.current
    val today = LocalDate.now()

    val levelInfo = remember(state) { ProgressEngine.calculateLevelInfo(state) }
    val currentStreak = remember(state, today) { ProgressEngine.calculateCurrentStreak(state, today) }
    val bestStreak = remember(state, today) { ProgressEngine.calculateBestStreak(state, today) }
    val sprintStats = remember(state, today) { ProgressEngine.calculateSprintStats(state, today) }
    val sphereStats = remember(state) { ProgressEngine.calculateSphereBreakdown(state) }
    val canFreezeYesterday = remember(state, today) { ProgressEngine.canFreezeYesterday(state, today) }

    var inspectedDate by remember { mutableStateOf(today) }
    val inspectedSummary = remember(state, inspectedDate) {
        ProgressEngine.calculateDaySummary(state, inspectedDate)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(key = "title") {
            Text(
                text = "Прогресс и аналитика",
                style = MaterialTheme.typography.headlineSmall,
                color = colors.textPrimary
            )
        }

        item(key = "kpi_row") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    modifier = Modifier.weight(1f),
                    label = "Серия",
                    value = "$currentStreak дн.",
                    subValue = "Рекорд: $bestStreak",
                    accent = colors.flame,
                    icon = Icons.Rounded.LocalFireDepartment
                )
                KpiCard(
                    modifier = Modifier.weight(1f),
                    label = if (state.settings.showXpAndLevels) "Всего XP" else "Неделя",
                    value = if (state.settings.showXpAndLevels) "${levelInfo.totalEarnedXp}" else "${sprintStats.currentWeekExecutionPercent}%",
                    subValue = if (state.settings.showXpAndLevels) "Ур. ${levelInfo.level} • ${levelInfo.rankTitle}" else "Цель: 85%",
                    accent = colors.accent,
                    icon = if (state.settings.showXpAndLevels) Icons.Rounded.Bolt else Icons.Rounded.TrendingUp
                )
            }
        }

        item(key = "heatmap") {
            HeatmapCard(
                state = state,
                today = today,
                inspectedDate = inspectedDate,
                inspectedPercent = inspectedSummary.completionPercent,
                inspectedEarnedXp = inspectedSummary.earnedXp,
                inspectedFrozen = inspectedSummary.isFrozen,
                showXp = state.settings.showXpAndLevels,
                onInspectDate = { inspectedDate = it },
                onOpenDay = { onOpenDay(inspectedDate) }
            )
        }

        if (state.settings.showSprintBar) {
            item(key = "sprint") {
                SprintCard(
                    goalTitle = state.settings.sprintGoalTitle,
                    currentWeek = sprintStats.currentWeek,
                    totalWeeks = sprintStats.totalWeeks,
                    daysRemaining = sprintStats.daysRemaining,
                    weekPercent = sprintStats.currentWeekExecutionPercent,
                    sprintPercent = sprintStats.sprintExecutionPercent
                )
            }
        }

        item(key = "spheres") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.border, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Баланс сфер",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )

                val allZero = sphereStats.all { it.earnedXp == 0 }
                if (allZero) {
                    Text(
                        text = "Выполните первые привычки или задачи — здесь появится распределение вашей энергии по сферам.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                } else {
                    sphereStats.forEach { stat ->
                        val sColor = Color(stat.sphere.colorHex)
                        val animatedShare by animateFloatAsState(
                            targetValue = (stat.sharePercent / 100f).coerceIn(0f, 1f),
                            label = "sphere_bar"
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(sColor)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = stat.sphere.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = colors.textPrimary
                                    )
                                }
                                Text(
                                    text = "${stat.sharePercent}% • ${stat.completedCount} вып.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.textSecondary
                                )
                            }
                            LinearProgressIndicator(
                                progress = { animatedShare },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(6.dp)),
                                color = sColor,
                                trackColor = colors.surfaceElevated,
                                strokeCap = StrokeCap.Round
                            )
                        }
                    }
                }
            }
        }

        item(key = "freeze_vault") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.border, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.AcUnit,
                            contentDescription = null,
                            tint = colors.freeze,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Фонд заморозки",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )
                    }
                    Text(
                        text = "Жетонов: ${state.freezeTokens}",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.freeze
                    )
                }

                Text(
                    text = "Жетон закрывает пропущенный день и не даёт серии сгореть при форс-мажоре. Свободный баланс: ${levelInfo.availableXp} XP.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onBuyFreezeToken,
                        enabled = levelInfo.availableXp >= state.settings.freezeCostXp,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = colors.freeze,
                            contentColor = Color(0xFF04131C)
                        )
                    ) {
                        Text(
                            text = "Купить (${state.settings.freezeCostXp} XP)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (canFreezeYesterday) {
                        OutlinedButton(
                            onClick = { onFreezeDate(today.minusDays(1)) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Спасти вчера",
                                style = MaterialTheme.typography.labelMedium,
                                color = colors.freeze
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiCard(
    modifier: Modifier,
    label: String,
    value: String,
    subValue: String,
    accent: Color,
    icon: ImageVector
) {
    val colors = LocalMomentumColors.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = colors.textSecondary
            )
        }
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            color = colors.textPrimary
        )
        Text(
            text = subValue,
            style = MaterialTheme.typography.labelSmall,
            color = accent
        )
    }
}

@Composable
private fun HeatmapCard(
    state: MomentumState,
    today: LocalDate,
    inspectedDate: LocalDate,
    inspectedPercent: Int,
    inspectedEarnedXp: Int,
    inspectedFrozen: Boolean,
    showXp: Boolean,
    onInspectDate: (LocalDate) -> Unit,
    onOpenDay: () -> Unit
) {
    val colors = LocalMomentumColors.current
    val currentMonday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val gridStartMonday = currentMonday.minusWeeks(12)
    val ruLocale = remember { Locale.forLanguageTag("ru") }
    val formatter = remember(ruLocale) { DateTimeFormatter.ofPattern("d MMM yyyy", ruLocale) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Матрица ритма (90 дней)",
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary
            )
            Text(
                text = "13 недель",
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val dayLabels = listOf("Пн", "", "Ср", "", "Пт", "", "Вс")
            for (dowIndex in 0..6) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = dayLabels[dowIndex],
                        modifier = Modifier.width(20.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = colors.textSecondary
                    )
                    for (weekCol in 0..12) {
                        val cellDate = gridStartMonday.plusWeeks(weekCol.toLong()).plusDays(dowIndex.toLong())
                        val isFuture = cellDate.isAfter(today)
                        val summary = if (!isFuture) ProgressEngine.calculateDaySummary(state, cellDate) else null
                        val cellColor = when {
                            isFuture -> colors.surfaceElevated.copy(alpha = 0.25f)
                            summary?.isFrozen == true -> colors.freeze.copy(alpha = 0.75f)
                            (summary?.completionPercent ?: 0) >= 85 -> colors.accent
                            (summary?.completionPercent ?: 0) >= 60 -> colors.accent.copy(alpha = 0.65f)
                            (summary?.completionPercent ?: 0) >= 30 -> colors.accent.copy(alpha = 0.35f)
                            (summary?.completionPercent ?: 0) > 0 -> colors.accent.copy(alpha = 0.18f)
                            else -> colors.surfaceElevated
                        }
                        val isSelected = cellDate == inspectedDate

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(cellColor)
                                .border(
                                    width = if (isSelected) 1.5.dp else 0.dp,
                                    color = if (isSelected) colors.textPrimary else Color.Transparent,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable(enabled = !isFuture) { onInspectDate(cellDate) }
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(colors.surfaceElevated)
                .clickable { onOpenDay() }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = inspectedDate.format(formatter) + if (inspectedFrozen) " (Заморожен)" else "",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textPrimary
            )
            Text(
                text = if (showXp) "$inspectedPercent% • +$inspectedEarnedXp XP  →" else "$inspectedPercent%  →",
                style = MaterialTheme.typography.labelMedium,
                color = colors.accent
            )
        }
    }
}

@Composable
private fun SprintCard(
    goalTitle: String,
    currentWeek: Int,
    totalWeeks: Int,
    daysRemaining: Int,
    weekPercent: Int,
    sprintPercent: Int
) {
    val colors = LocalMomentumColors.current
    val weekAnim by animateFloatAsState(targetValue = (weekPercent / 100f).coerceIn(0f, 1f), label = "week_bar")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "12-НЕДЕЛЬНЫЙ ГОД",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.accent,
                    letterSpacing = 1.sp
                )
                Text(
                    text = goalTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(colors.surfaceElevated)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "Нед. $currentWeek/$totalWeeks",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textPrimary
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Индекс текущей недели (ориентир 85%)",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textSecondary
                )
                Text(
                    text = "$weekPercent%",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (weekPercent >= 85) colors.accent else colors.textPrimary
                )
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                LinearProgressIndicator(
                    progress = { weekAnim },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = if (weekPercent >= 85) colors.accent else colors.flame,
                    trackColor = colors.surfaceElevated,
                    strokeCap = StrokeCap.Round
                )
                Box(
                    modifier = Modifier
                        .offset(x = maxWidth * 0.85f)
                        .width(2.dp)
                        .height(12.dp)
                        .clip(RoundedCornerShape(1.dp))
                        .background(colors.textPrimary.copy(alpha = 0.7f))
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Средний индекс спринта: $sprintPercent%",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
            Text(
                text = "Осталось $daysRemaining дн.",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
        }
    }
}
