package com.momentum.app.data

import kotlinx.serialization.Serializable
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.UUID

@Serializable
data class Sphere(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val colorHex: Long
)

@Serializable
enum class HabitTier(val label: String) {
    NONE("Пропуск"),
    MIN("Мин"),
    BASE("База"),
    MAX("Макс")
}

@Serializable
data class Habit(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val sphereId: String,
    val isElastic: Boolean = true,
    val daysOfWeek: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    val minLabel: String = "5 мин",
    val baseLabel: String = "20 мин",
    val maxLabel: String = "45 мин",
    val xpMin: Int = 10,
    val xpBase: Int = 25,
    val xpMax: Int = 50,
    val createdDate: String = LocalDate.now().toString(),
    val archived: Boolean = false
) {
    fun xpFor(tier: HabitTier): Int = when (tier) {
        HabitTier.NONE -> 0
        HabitTier.MIN -> xpMin
        HabitTier.BASE -> xpBase
        HabitTier.MAX -> xpMax
    }
}

@Serializable
data class TaskItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val note: String = "",
    val sphereId: String,
    val date: String? = null,
    val priority: Int = 1,
    val isCompleted: Boolean = false,
    val completedDate: String? = null
) {
    val xpReward: Int
        get() = when (priority) {
            3 -> 50
            2 -> 30
            else -> 15
        }
}

@Serializable
data class EventItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val note: String = "",
    val sphereId: String,
    val date: String,
    val time: String = "",
    val isCompleted: Boolean = false,
    val xpReward: Int = 20
)

@Serializable
data class DayRecord(
    val habitCompletions: Map<String, HabitTier> = emptyMap(),
    val note: String = ""
)

@Serializable
enum class AccentPreset(val title: String, val hex: Long) {
    EMERALD("Изумруд", 0xFF10B981),
    COBALT("Кобальт", 0xFF3B82F6),
    AMBER("Янтарь", 0xFFF59E0B),
    CORAL("Коралл", 0xFFF43F5E),
    VIOLET("Аметист", 0xFF8B5CF6),
    MONOCHROME("Монохром", 0xFFE2E8F0)
}

@Serializable
data class AppSettings(
    val darkTheme: Boolean = true,
    val accentPreset: AccentPreset = AccentPreset.EMERALD,
    val showXpAndLevels: Boolean = true,
    val showSprintBar: Boolean = true,
    val hapticEnabled: Boolean = true,
    val dailyStreakThresholdPercent: Int = 60,
    val sprintLengthWeeks: Int = 12,
    val sprintStartDate: String = LocalDate.now()
        .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        .toString(),
    val sprintGoalTitle: String = "Главный фокус спринта",
    val freezeCostXp: Int = 200
)

@Serializable
data class MomentumState(
    val spheres: List<Sphere> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val tasks: List<TaskItem> = emptyList(),
    val events: List<EventItem> = emptyList(),
    val dayRecords: Map<String, DayRecord> = emptyMap(),
    val spentXp: Int = 0,
    val freezeTokens: Int = 1,
    val frozenDates: Set<String> = emptySet(),
    val settings: AppSettings = AppSettings()
)

object SpherePalette {
    val presets: List<Pair<String, Long>> = listOf(
        "Изумруд" to 0xFF10B981,
        "Кобальт" to 0xFF3B82F6,
        "Аметист" to 0xFF8B5CF6,
        "Янтарь" to 0xFFF59E0B,
        "Коралл" to 0xFFF43F5E,
        "Бирюза" to 0xFF06B6D4,
        "Лайм" to 0xFF84CC16,
        "Сталь" to 0xFF94A3B8
    )

    fun defaultState(today: LocalDate = LocalDate.now()): MomentumState {
        val focusSphere = Sphere(id = "sphere_focus", name = "Дело / Фокус", colorHex = 0xFF3B82F6)
        val bodySphere = Sphere(id = "sphere_body", name = "Форма / Энергия", colorHex = 0xFF10B981)
        val growthSphere = Sphere(id = "sphere_growth", name = "Развитие", colorHex = 0xFF8B5CF6)
        val lifeSphere = Sphere(id = "sphere_life", name = "Личное", colorHex = 0xFFF59E0B)

        val todayStr = today.toString()
        val mondayStr = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()

        val starterHabits = listOf(
            Habit(
                id = "habit_deep_work",
                title = "Глубокий фокус без отвлечений",
                sphereId = focusSphere.id,
                isElastic = true,
                daysOfWeek = setOf(1, 2, 3, 4, 5, 6, 7),
                minLabel = "15 мин",
                baseLabel = "45 мин",
                maxLabel = "90 мин",
                createdDate = today.minusDays(7).toString()
            ),
            Habit(
                id = "habit_training",
                title = "Тренировка / активность",
                sphereId = bodySphere.id,
                isElastic = true,
                daysOfWeek = setOf(1, 2, 3, 4, 5, 6, 7),
                minLabel = "Разминка",
                baseLabel = "База",
                maxLabel = "Полная",
                createdDate = today.minusDays(7).toString()
            ),
            Habit(
                id = "habit_reading",
                title = "Чтение и конспект",
                sphereId = growthSphere.id,
                isElastic = false,
                daysOfWeek = setOf(1, 2, 3, 4, 5, 6, 7),
                createdDate = today.minusDays(7).toString()
            )
        )

        val starterTasks = listOf(
            TaskItem(
                id = "task_setup",
                title = "Настроить сферы и цели 12-недельного спринта",
                note = "Зайти в Настройки и задать свой главный фокус",
                sphereId = focusSphere.id,
                date = todayStr,
                priority = 2
            ),
            TaskItem(
                id = "task_plan",
                title = "Наметить 3 ключевых шага на неделю",
                sphereId = growthSphere.id,
                date = todayStr,
                priority = 1
            )
        )

        val starterEvents = listOf(
            EventItem(
                id = "event_review",
                title = "Вечерний чек-ин дня",
                note = "Отметить привычки и зафиксировать прогресс",
                sphereId = lifeSphere.id,
                date = todayStr,
                time = "21:00",
                xpReward = 20
            )
        )

        return MomentumState(
            spheres = listOf(focusSphere, bodySphere, growthSphere, lifeSphere),
            habits = starterHabits,
            tasks = starterTasks,
            events = starterEvents,
            dayRecords = emptyMap(),
            spentXp = 0,
            freezeTokens = 1,
            frozenDates = emptySet(),
            settings = AppSettings(sprintStartDate = mondayStr)
        )
    }
}
