-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.momentum.app.data.**$$serializer { *; }
-keepclassmembers class com.momentum.app.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.momentum.app.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}
